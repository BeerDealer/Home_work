const signupRouter = require("./api.signup");
const test = require("./test");

module.exports = [signupRouter, test];
